import yaml
import json
import copy
import argparse
from RstBuilder import RstBuilder
from HTMLParser import MyHTMLParser

NAME_TAG = "@LONG-NAME"


def init_argument():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "-i",
        "--input_file",
        default="./Requirements.json",
        help="Directory to input file. Accepts file *.json only",
    )
    parser.add_argument(
        "-o",
        "--output_file",
        default="./Requirements.rst",
        help="Directory to output *.rst file.",
    )
    parser.add_argument(
        "-s",
        "--settings",
        default="./config.yml",
        help="Directory to configure settings *.yml file",
    )

    args = parser.parse_args()

    return args.input_file, args.output_file, args.settings


def load_config(filename: str) -> dict:
    """
    Loads the config file and returns the module config
    """
    return yaml.safe_load(open(filename, "r"))["module"]


def load_json(filename: str) -> dict:
    """
    Loads the json file and returns the json content
    """
    return json.load(open(filename))


def find_property_have_key(obj: dict, target: str):
    """
    Returns the property that have the given key
    """
    for key, value in obj.items():
        if value.get("key") == target:
            return key, value


def listify(obj):
    """
    Returns a list of the object if it is not a list
    """
    return obj if isinstance(obj, list) else [obj]


def get_directives_data(artifact: dict, directives: list):
    """
    Returns the directives data for the given artifact
    """
    for directive in listify(directives):
        # Attribute Value text
        for key, value in directive.get("attributes", {}).items():
            attr = find_property_have_key(config["artifacts"]["artifact"], value)

            directive["attributes"][key] = artifact.get(value, value)

        # HTML Content
        content = directive.get("html_content", "")
        attr = find_property_have_key(config["artifacts"]["artifact"], content)
        if attr is not None:
            parser = MyHTMLParser()
            parser.feed(artifact.get(content, content))
            directive["html_content"] = parser.get_rst()

        # Sub_directive, at the end of the rst
        if "sub_directives" in directive.keys():
            for key, value in directive.get("sub_directives", {}).items():
                attr = find_property_have_key(config["artifacts"]["artifact"], value)

                # If "value: ..." does not set in config list artifacts,
                # then the value works as the key in Json, query directly from Json
                directive["sub_directives"][key] = artifact.get(value, value)

        # In case there are directives in directive
        if "directives" in directive:
            # recursively, directive in directive
            directive["directives"] = get_directives_data(
                artifact, directive["directives"]
            )
    return directives


def get_rst_type(artifact_type, rst_config):
    """
    Returns the rst type for the given artifact type
    """
    if artifact_type == rst_config["heading"]["atifact_type"]:
        return "heading"
    if artifact_type == rst_config["information"]["atifact_type"]:
        return "information"
    return "other"


def build_rst_artifacts(rst, artifacts: list, config: dict):
    rst_config = config["__rst__"]

    for artifact in artifacts:
        artifact_type = artifact[config["type"]["key"]]
        rst_type = get_rst_type(artifact_type, rst_config)

        if rst_type == "heading":
            attr_name = rst_config[rst_type]["value"]
            rst.subheading(artifact[attr_name])
            rst.newline()
        else:
            directives_config = copy.deepcopy(
                rst_config[rst_type].get("directives", [])
            )
            directives = listify(get_directives_data(artifact, directives_config))
            rst.directives(directives)
            rst.newline()


if __name__ == "__main__":
    INP_PATH, OUT_PATH, CFG_PATH = init_argument()
    config = load_config(CFG_PATH)
    data = load_json(INP_PATH)

    rst = RstBuilder(open(OUT_PATH, "w"))
    rst.newline()
    rst.heading(data[config["name"]["key"]])
    rst.newline()
    artifacts = data[config["artifacts"]["key"]]
    build_rst_artifacts(rst, artifacts, config["artifacts"]["artifact"])
